from flask import Flask, request, url_for, jsonify,make_response
import pymysql
from flask_cors import *
import pandas as pd
from collections import Counter
import os

from werkzeug.utils import secure_filename
DATA_TOTAL={}
YIQING={}
import DA
import yiqing
import weather

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False  # jsonify输出正确中文
CORS(app, supports_credentials=True)  # 跨域请求

from flask.json import JSONEncoder as _JSONEncoder


# 解决falsk json格式下小数不是正确格式的问题
class JSONEncoder(_JSONEncoder):
    def default(self, o):
        import decimal
        if isinstance(o, decimal.Decimal):
            return float(o)

        super(JSONEncoder, self).default(o)


app.json_encoder = JSONEncoder


@app.route('/page1', methods=['GET'])  # 路由，方法为get
def page1():  # 接口一
    if (len(request.args) != 0):  # 获取url传来的值为列表里面套元组
        data_year = request.args['year']
        data_month = request.args['month']
        sql = "SELECT SUM(box_office) from films where type LIKE '%喜剧%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%冒险%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%传记%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%剧情%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%战争%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%奇幻%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%家庭%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%历史%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%科幻%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%惊悚%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%悬疑%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%爱情%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%犯罪%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%动画%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%运动%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%恐怖%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%纪录片%' and `year` = " + data_year + " and `month` = " + data_month + \
              " UNION SELECT SUM(box_office) from films where type LIKE '%动作%' and `year` = " + data_year + " and `month` = " + data_month
    else:
        sql = "SELECT SUM(box_office) from films where type LIKE '%喜剧%' " \
              "UNION SELECT SUM(box_office) from films where type LIKE '%冒险%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%传记%'" \
              "UNION SELECT SUM(box_office) from films where type LIKE '%剧情%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%战争%'" \
              "UNION SELECT SUM(box_office) from films where type LIKE '%奇幻%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%家庭%'" \
              "UNION SELECT SUM(box_office) from films where type LIKE '%历史%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%科幻%'" \
              "UNION SELECT SUM(box_office) from films where type LIKE '%惊悚%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%悬疑%'" \
              "UNION SELECT SUM(box_office) from films where type LIKE '%爱情%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%犯罪%'" \
              "UNION SELECT SUM(box_office) from films where type LIKE '%动画%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%运动%'" \
              "UNION SELECT SUM(box_office) from films where type LIKE '%恐怖%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%纪录片%'" \
              " UNION SELECT SUM(box_office) from films where type LIKE '%动作%'"
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyan',
                           charset='utf8')

    cursor = conn.cursor()
    cursor.execute(sql)
    values = cursor.fetchall()  # 获得了所有的数据
    jsondata = {}
    xd = []
    yd = ['喜剧', '冒险', '传记', '剧情', '战争', '奇幻', '家庭', '历史', '科幻',
          '惊悚', '悬疑', '爱情', '犯罪', '动画', '运动', '恐怖', '纪录片', '动作']
    datas = []
    for index, i in enumerate(values):
        mydict = {}
        mydict["value"] = i[0]
        mydict["name"] = yd[index]
        datas.append(mydict)
        xd.append(i[0])
    jsondata['categories'] = yd  # 类型
    jsondata['data'] = xd  # 数量
    jsondata['datas'] = datas  # 整个字典
    j = jsonify(jsondata)
    cursor.close()
    conn.close()
    return j


@app.route('/page2', methods=['GET'])
def page2():  # 票房榜单
    if (len(request.args) != 0):
        data_year = request.args['year']
        data_top = request.args['top']
        sql = "SELECT `name`,box_office from films WHERE `year` = " + data_year + " ORDER BY box_office DESC LIMIT 0," + data_top
    else:
        sql = "SELECT `name`,box_office from films ORDER BY box_office DESC LIMIT 0,20"
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyan',
                           charset='utf8')

    cursor = conn.cursor()
    cursor.execute(sql)
    values = cursor.fetchall()
    jsondata = {}
    datas = []
    for index, i in enumerate(values):
        mydict = {}
        mydict["value"] = i[1]
        mydict["name"] = i[0]
        datas.append(mydict)
    jsondata['datas'] = datas  # 获得字典
    j = jsonify(jsondata)
    cursor.close()
    conn.close()
    return j


@app.route('/page3', methods=['GET'])
def page3():  # 票房变化
    if (len(request.args) != 0):
        data_type = request.args['type']
        sql = "SELECT SUM(box_office) from films where `year` = 2015 and `type` LIKE '%" + data_type + "%' " \
                                                                                                       " UNION SELECT SUM(box_office) from films where `year` = 2016 and `type` LIKE '%" + data_type + "%' " \
                                                                                                                                                                                                       " UNION SELECT SUM(box_office) from films where `year` = 2017 and `type` LIKE '%" + data_type + "%' " \
                                                                                                                                                                                                                                                                                                       " UNION SELECT SUM(box_office) from films where `year` = 2018 and `type` LIKE '%" + data_type + "%' " \
                                                                                                                                                                                                                                                                                                                                                                                                       " UNION SELECT SUM(box_office) from films where `year` = 2019 and `type` LIKE '%" + data_type + "%' "
    else:
        sql = "SELECT SUM(box_office) from films where `year` = 2015" \
              " UNION SELECT SUM(box_office) from films where `year` = 2016" \
              " UNION SELECT SUM(box_office) from films where `year` = 2017" \
              " UNION SELECT SUM(box_office) from films where `year` = 2018" \
              " UNION SELECT SUM(box_office) from films where `year` = 2019"
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyan',
                           charset='utf8')

    cursor = conn.cursor()
    cursor.execute(sql)
    values = cursor.fetchall()
    jsondata = {}
    xd = []
    for index, i in enumerate(values):
        xd.append(i[0])
    jsondata['data'] = xd
    j = jsonify(jsondata)
    cursor.close()
    conn.close()
    return j


@app.route('/page4', methods=['GET'])
def page4():  # 劳模
    data_year = ''
    if (len(request.args) != 0):
        data_year = request.args['year']
        data_top = int(request.args['top'])
    else:
        data_top = 10
    sql = "select year,actor1,actor2,actor3,actor4 from films"
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyan',
                           charset='utf8')
    db_0 = pd.read_sql(sql, conn)
    if (len(data_year) != 0):
        db = db_0[(db_0.year == int(data_year))]
    else:
        db = db_0
    dict_ = dict(
        Counter(db['actor1'].append(db['actor2']).append(db['actor3']).append(db['actor4']).dropna()).most_common(
            data_top))
    x = list(dict_.keys())
    y = list(dict_.values())
    datas = []
    for index in range(len(x)):
        mydict = {}
        mydict["value"] = y[index]
        mydict["name"] = x[index]
        datas.append(mydict)
    jsondata = {}
    jsondata['data'] = datas
    jsondata['name'] = x
    jsondata['value'] = y
    j = jsonify(jsondata)
    return j


@app.route('/data1', methods=['GET'])
def data1():
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyantest', charset='utf8')
    cursor = conn.cursor()
    cursor.execute("select * from students")
    count = cursor.fetchall()
    jsondata = {}
    datas = []
    for index, i in enumerate(count):
        mydict = {}
        mydict["id"] = i[0]
        mydict["name"] = i[1]
        mydict["age"] = i[2]
        mydict["sex"] = i[3]
        datas.append(mydict)
    jsondata['datas'] = datas
    js001 = {
        "code": 0,
        "msg": "",
        "count": 1000,
        "data": jsondata['datas']
    }
    j = jsonify(js001)
    cursor.close()
    conn.close()
    return j


@app.route('/data2', methods=['GET'])
def data2():
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyantest', charset='utf8')
    cursor = conn.cursor()

    name = request.args['name'].encode("utf-8").decode('utf-8')
    age = request.args['age']
    sex = request.args['sex']
    id = request.args['id']
    print(name, age, sex, id)
    name = "\'" + name + "\'"
    if sex == 'man':
        sex = '男'
    else:
        sex = '女'
    sex = "\'" + sex + "\'"
    sql = 'INSERT INTO students(id,name,age,sex) VALUES ({},{},{},{})'.format(id, name, age, sex)
    print(sql)
    if cursor.execute(sql):
        conn.commit()
        print("Successful")
    cursor.close()
    conn.close()
    return 'ok'


@app.route('/data3', methods=['GET'])
def data3():
    id = request.args['id']
    print(id)
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyantest', charset='utf8')
    cursor = conn.cursor()
    sql = "DELETE FROM students WHERE id = {}".format(id)
    if cursor.execute(sql):
        conn.commit()
        print("Successful")
    cursor.close()
    conn.close()
    return 'ok'


@app.route('/ana', methods=['POST', 'GET'])
def ana():
    global DATA_TOTAL
    file = request.files['file']
    file.save('DataAnalysis/DATA/' + secure_filename(file.filename))
    f = DA.file_name('DataAnalysis/DATA/')
    dict = DA.createindex(f)
    datademo={}
    for i in range(len(dict)):
        datademo[i]=dict[i]
    data = {
        "code": 0, "msg": "","count": 1000, "data":datademo
    }
    DATA_TOTAL=datademo
    print(data)
    data2 = jsonify(data)
    return data2

@app.route('/ana1',methods=['POST', 'GET'])
def ana1():
    global DATA_TOTAL
    index = int(request.args['name'])
    print(index)
    print(DATA_TOTAL)
    data_item=DATA_TOTAL[index]
    print(data_item)
    data_analysis=DA.dataget(data_item)
    print(data_analysis)
    data = jsonify(data_analysis)
    return data

@app.route('/ana2',methods=['POST', 'GET'])
def ana2():
    global DATA_TOTAL
    index = int(request.args['name'])
    data_item=DATA_TOTAL[index]
    print(data_item)
    data_analysis=DA.dataget2(data_item)
    print(data_analysis)
    data = jsonify(data_analysis)
    return data

@app.route('/ana3',methods=['POST', 'GET'])
def ana3():
    global DATA_TOTAL
    DATA_TOTAL ={}
    f = DA.file_name('DataAnalysis/DATA/')
    result = os.remove(f)
    data= {
        'result':result
    }
    rsp = make_response()
    rsp.headers['Content-Type']='multipart/form-data'
    data=jsonify(data)
    return  data


@app.route('/lol', methods=['GET'])
def lol():
    global DATA_TOTAL
    data = jsonify(DATA_TOTAL)
    return data

@app.route('/bin',methods=['GET','POST'])
def bin():
    global DATA_TOTAL
    index = int(request.args['name'])
    data_item = DATA_TOTAL[index]
    list = DA.bins(data_item)
    data={
        data_item : list
    }
    result = jsonify(data)
    return result

@app.route('/img1',methods=['GET','POST'])
def img1():
    global DATA_TOTAL
    index = int(request.args['name'])
    data_item = DATA_TOTAL[index]
    lexing=int(request.args['location'])
    if lexing ==1:
        data = DA.distribution(data_item)
        os.remove('DataAnalysis/IMAGES/qq.png')
    elif lexing ==2:
        data = DA.tcheck(data_item)
        os.remove('DataAnalysis/IMAGES/tcheck.png')
    elif lexing ==3:
        data = DA.realtion()
        os.remove('DataAnalysis/IMAGES/img.png')
    data =jsonify(data)
    return data

@app.route('/data', methods=['GET'])
def data():  # 数据概况
    limit = int(request.args['limit'])
    page = int(request.args['page'])
    page = (page - 1) * limit
    conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyan',
                           charset='utf8')

    cursor = conn.cursor()
    cursor.execute("select count(*) from films");
    count = cursor.fetchall()
    cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)
    cursor.execute("select * from films limit " + str(page) + "," + str(limit));
    data_dict = []
    result = cursor.fetchall()
    for field in result:
        data_dict.append(field)
    table_result = {"code": 0, "msg": None, "count": count[0], "data": data_dict}
    cursor.close()
    conn.close()
    return jsonify(table_result)

@app.route('/yiqingmain',methods=['GET','POST'])
def yiqingmain():
    global YIQING
    YIQING=yiqing.main()
    list = YIQING['Total']
    data ={
        'Total':list
    }
    # print(data)
    data=jsonify(data)
    return  data

@app.route('/xiangxishuju',methods=['GET','POST'])
def xiangxishuju():
    global YIQING
    listand=[]
    list = YIQING['Amercian']
    for l in list:
        dd={}
        dd['area']=l[0]
        dd['get']=l[1]
        dd['death']=l[2]
        listand.append(dd)
    data = {
        "code": 0,
        "count": 15,  # 34,215
        "data": listand
        }
    data=jsonify(data)
    return data

@app.route('/xiangxishuju2',methods=['GET','POST'])
def xiangxishuju2():
    global YIQING
    listand=[]
    list = YIQING['Chinese']
    for l in list:
        dd={}
        dd['area']=l[0]
        dd['get']=l[1]
        dd['death']=l[2]
        dd['cure']=l[3]
        listand.append(dd)
    data = {
        "code": 0,
        "count": 34,  # 34,215
        "data": listand
        }
    data=jsonify(data)
    return data

@app.route('/xiangxishuju3',methods=['GET','POST'])
def xiangxishuju3():
    global YIQING
    listand=[]
    list = YIQING['Country']
    for l in list:
        dd={}
        dd['area']=l[0]
        dd['get']=l[1]
        dd['death']=l[2]
        dd['cure']=l[3]
        listand.append(dd)
    data = {
        "code": 0,
        "count": 215,  # 34,215
        "data": listand
        }
    data=jsonify(data)
    return data

@app.route('/top10confirm',methods=['GET'])
def top10confirm():
    global YIQING
    listand=[]
    list = YIQING['Country']
    for l in list[:10]:
        dd = {}
        dd['area'] = l[0]
        dd['get'] = l[1]
        listand.append(dd)
    data={
        "data": listand
    }
    data = jsonify(data)
    return data

@app.route('/top10death',methods=['GET'])
def top10death():
    global YIQING
    listand = []
    list = YIQING['Country']
    list = sorted(list,key=lambda x:int(x[2]),reverse=True)
    for l in list[:10]:
        dd = {}
        dd['area'] = l[0]
        dd['death'] = l[2]
        listand.append(dd)
    data={
        "data": listand
    }
    data = jsonify(data)
    return data

@app.route('/top20',methods=['GET','POST'])
def top20():
    global YIQING
    index = int(request.args['name'])
    if index == 1:
        list = YIQING['Country']
        area = []
        get=[]
        cure=[]
        bili=[]
        for l in list[:20]:
            area.append(l[0])
            get.append(l[1])
            if int(l[3]) == -1:
                l[3] = 1
            cure.append(l[3])
            bili.append(int(l[3])/int(l[1]))
        data = {
            "area": area,
            "get":get,
            "cure":cure,
            "bili":bili,
        }
        data = jsonify(data)
        return data
    else:
        list = YIQING['Country']
        area = []
        get = []
        death = []
        bili = []
        for l in list[:20]:
            area.append(l[0])
            get.append(l[1])
            death.append(l[2])
            bili.append(int(l[2]) / int(l[1]))
        data = {
            "area": area,
            "get": get,
            "death": death,
            "bili": bili,
        }
        data = jsonify(data)
        return data

@app.route('/index01',methods=['GET','POST'])
def index01():
    global DATA_TOTAL
    index = int(request.args['name'])
    data_item = DATA_TOTAL[index]
    list=DA.bins(data_item)
    data={
        "result":list
    }
    data=jsonify(data)
    return data

@app.route('/cluster',methods=['GET','POST'])
def cluster():
    global DATA_TOTAL
    LIST=[]
    for key, value in DATA_TOTAL.items():
        list = DA.bins(value)
        LIST.append(list)
    print(LIST)
    data={
        "result":LIST
    }
    data=jsonify(data)
    return data

@app.route('/weather11',methods=['GET','POST'])
def weather11():
    city = request.args['city']
    number = weather.getcitynumber(city)
    data = weather.getinformation(number)
    data = jsonify(data)
    return data

if __name__ == "__main__":
    app.run(port=5000,debug=True)
