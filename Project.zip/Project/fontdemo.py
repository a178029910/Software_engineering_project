# from fontTools.ttLib import TTFont
# import requests
# font = TTFont("font\\sdyjq.woff")
# font.saveXML('font.xml')
# best_map = font["cmap"].getBestCmap()
# new_best_map={}
# for key,value in best_map.items():
#     new_best_map[hex(key)] = value
# print(new_best_map)
# new_map={
#           'x': '',
#     'uniF816': '1',
#     'uniE069': '2',
#     'uniE9FA': '8',
#     'uniEFD2': '0',
#     'uniE7CF': '3',
#     'uniE26F': '6',
#     'uniF6D9': '5',
#     'uniEFF5': '7',
#     'uniEFD4': '9',
#     'uniEADF': '4',
# }
# new_date ={}
# for k,v in new_best_map.items():
#     new_date[k] = new_map[v]
# print(new_date)
# rs={}
# for k,v in new_date.items():
#     rs['&#'+k[1:]+';'] =v
# print(rs)
# url="https://maoyan.com/films/78405"
# header = {
#         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
#         'Accept-Encoding': 'gzip, deflate, br',
#         'Accept-Language': 'zh-CN,zh;q=0.9',
#         'Cache-Control': 'max-age=0',
#         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
#         'Refer': 'https://maoyan.com/films?showType=3&sortId=3&yearId=2019&offset=1',
#         'Cookie': '__mta=249977145.1583671185160.1583763144922.1583764039914.20; uuid_n_v=v1; uuid=E28D90A0613911EAB27ABDE6964F79434D1CC627A8C542068B482E27B9DD41F9; _lxsdk_cuid=170ba288a1dc8-09301f2aed33c1-4313f6a-1fa400-170ba288a1e0; mojo-uuid=9e304d4b079c736a09e72e01825d8a3f; mojo-session-id={"id":"1965d6cbe95905a4831014832c6ad168","time":1583760311686}; _csrf=1a8231d68001a5ec67bdd70093d70c189f0e80e98293577f0c3406a03b2b1ca1; Hm_lvt_703e94591e87be68cc8da0da7cbd0be2=1583671184,1583760312,1583760447; _lxsdk=E28D90A0613911EAB27ABDE6964F79434D1CC627A8C542068B482E27B9DD41F9; __mta=249977145.1583671185160.1583760682658.1583761215442.18; Hm_lpvt_703e94591e87be68cc8da0da7cbd0be2=1583764040; mojo-trace-id=61; _lxsdk_s=170bf7885a6-fdc-a22-08%7C%7C103'
#     }
# resp = requests.get(url=url, headers=header).text
# for k,v in rs.items():
#     if k in resp:
#         resp = resp.replace(k,v)
# with open('cc.html','w',encoding='utf-8')as f:
#     f.write(resp)
list=[[1,2,'3'],[2,3,'4'],[3,4,'1']]
print(sorted(list,key=lambda x:int(x[2])))