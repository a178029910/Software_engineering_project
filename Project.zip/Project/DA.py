import os
import pandas as pd
import numpy as np
import scipy.stats as ss
import seaborn as sns
from statsmodels.graphics.api import qqplot
from matplotlib import pyplot as plt
from base64 import b64encode
from json import dumps

def file_name(file_dir):
    for root, dirs, files in os.walk(file_dir):
        pass
    f='DataAnalysis/DATA/'+files[0]
    return f

def createindex(f):
    df = pd.read_excel(f,'Sheet1')
    df.to_csv('data.csv',encoding='utf-8')
    # df=pd.read_csv(data)
    # print(df)
    labels = list(df.columns.values) # 获得第一行元素
    return labels

def dataget(index):
    f = file_name('DataAnalysis/DATA/')
    df = pd.read_excel(f, 'Sheet1')
    df.to_csv('data.csv', encoding='utf-8')
    # print(df.mean())  # 平均值
    mean = float(df[index].mean())
    # print(df.median())  # 中位数
    median = float(df[index].median())
    # print(df.mode())  # 众数
    mode = float(df[index].mode()[0])
    # print(df.sum())  # 求和
    sum = float(df[index].sum())
    # print(df.std())  # 标准
    std = float(df[index].std())
    # print(df.var())  # 方差
    var = float(df[index].var())
    # print(df.skew())  # 偏态
    skew = float(df[index].skew())
    # print(df.kurt())  # 峰态
    kurt = float(df[index].kurt())
    data = {
        'mean':mean ,
        'median':median,
        'mode' : mode,
        'sum' : sum,
        'std' : std,
        'var1' : var,
        'skew' : skew,
        'kurt':kurt
    }
    return  data

def dataget2(index):
    f = file_name('DataAnalysis/DATA/')
    df = pd.read_excel(f, 'Sheet1')
    df.to_csv('data.csv', encoding='utf-8')
    sl_s = df[index]
    sl_s = sl_s.dropna()
    q_low = sl_s.quantile(q=0.25)  # 下四分位数
    q_high = sl_s.quantile(q=0.75)  # 上四分位数
    k = 1.5
    q_interval = q_high - q_low
    # 异常值过滤
    sl_s = sl_s[sl_s < q_high + k * q_interval][sl_s > q_low - k * q_interval]
    mean = float(sl_s.mean())
    median = float(sl_s.median())
    mode = float(sl_s.mode()[0])
    sum = float(sl_s.sum())
    std = float(sl_s.std())
    var = float(sl_s.var())
    skew = float(sl_s.skew())
    kurt = float(sl_s.kurt())
    data = {
        'mean':mean ,
        'median':median,
        'mode' : mode,
        'sum' : sum,
        'std' : std,
        'var1' : var,
        'skew' : skew,
        'kurt':kurt
    }
    return  data


def distribution(index):
    np.seterr(divide='ignore', invalid='ignore')
    data={}
    f = file_name('DataAnalysis/DATA/')
    df = pd.read_excel(f, 'Sheet1')
    df.to_csv('data.csv', encoding='utf-8')
    statistic = ss.normaltest(df[index]).statistic
    pvalue =ss.normaltest(df[index]).pvalue
    fig1 =qqplot(df[index])  # QQ图
    fig1.savefig('DataAnalysis/IMAGES/qq.png')
    with open('DataAnalysis/IMAGES/qq.png', 'rb') as jpg_file:
        byte_content = jpg_file.read()
    # 把原始字节码编码成 base64 字节码
        base64_bytes = b64encode(byte_content)
        base64_string = base64_bytes.decode('utf-8')
        data['src']=base64_string
    data['statistic']=statistic
    data['pvalue']=pvalue
    data['statistic'] = str(data['statistic'])
    data['pvalue'] = str(data['pvalue'])
    return data

def tcheck(index):
    np.seterr(divide='ignore', invalid='ignore')
    f = file_name('DataAnalysis/DATA/')
    df = pd.read_excel(f, 'Sheet1')
    df.to_csv('data.csv', encoding='utf-8')
    # 部分属性的t独立分布检验
    dp_indices = df.groupby(by=index).indices
    # sales_values = df["left"].iloc[dp_indices["sales"]].values
    # print(sales_values)
    # technical_values = df["left"].iloc[dp_indices["technical"]].values
    # print(technical_values)
    # print(ss.ttest_ind(sales_values, technical_values))
    dp_keys = list(dp_indices.keys())
    dp_t_mat = np.zeros((len(dp_keys), len(dp_keys)))
    for i in range(len(dp_keys)):
        for j in range(len(dp_keys)):
            p_value = ss.ttest_ind(df["left"].iloc[dp_indices[dp_keys[i]]].values, \
                                   df["left"].iloc[dp_indices[dp_keys[j]]].values)[1]
            if p_value < 0.05:
                dp_t_mat[i][j] = -1
            else:
                dp_t_mat[i][j] = p_value
    data={}
    sns_hist1 = sns.heatmap(dp_t_mat, xticklabels=dp_keys, yticklabels=dp_keys,annot=True,linewidths=0.3,linecolor="grey")
    fig = sns_hist1.get_figure()
    fig.savefig('DataAnalysis/IMAGES/tcheck.png')
    with open('DataAnalysis/IMAGES/tcheck.png', 'rb') as jpg_file:
        byte_content = jpg_file.read()
    # 把原始字节码编码成 base64 字节码
        base64_bytes = b64encode(byte_content)
        base64_string = base64_bytes.decode('utf-8')
        data['src']=base64_string
    return data
def realtion():
    np.seterr(divide='ignore', invalid='ignore')
    sns.set_context(font_scale=1.5)
    f = file_name('DataAnalysis/DATA/')
    df = pd.read_excel(f, 'Sheet1')
    df.to_csv('data.csv', encoding='utf-8')
    sns_hist =sns.heatmap(df.corr(),vmin=-1,vmax=1,cmap=sns.color_palette("RdBu",n_colors=128),annot=True,linewidths=0.3,linecolor="grey")
    fig = sns_hist.get_figure()
    fig.savefig('DataAnalysis/IMAGES/img.png')  # 路径+文件名
    data = {}
    with open('DataAnalysis/IMAGES/img.png', 'rb') as jpg_file:
        byte_content = jpg_file.read()
    # 把原始字节码编码成 base64 字节码
        base64_bytes = b64encode(byte_content)
        base64_string = base64_bytes.decode('utf-8')
        data['src']=base64_string
    return data

def bins(key):
    f = file_name('DataAnalysis/DATA/')
    df = pd.read_excel(f, 'Sheet1')
    df.to_csv('data.csv', encoding='utf-8')
    list = df[key].values.tolist()
    return list

# def cluster(key):
#     f = file_name('DataAnalysis/DATA/')
#     df = pd.read_excel(f, 'Sheet1')
#     df.to_csv('data.csv', encoding='utf-8')
#     print(df)

if __name__ == '__main__':
    # distribution()
    #  tcheck()
    realtion()