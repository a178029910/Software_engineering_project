import pymysql
from flask import Flask,request,url_for, jsonify
from flask_cors import CORS

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False  # jsonify输出正确中文
CORS(app, supports_credentials=True)  # 跨域请求

conn = pymysql.connect(host='127.0.0.1', user='root', password='123', port=3366, db='maoyantest',
                           charset='utf8')

cursor = conn.cursor()
cursor.execute("select * from students");
count = cursor.fetchall()

jsondata = {}
datas = []
for index,i in enumerate(count):
    mydict = {}
    mydict["id"] = i[0]
    mydict["name"] = i[1]
    mydict["age"] = i[2]
    mydict["sex"] = i[3]
    datas.append(mydict)
jsondata['datas'] = datas
# j = jsonify(jsondata)
print(jsondata)
cursor.close()
conn.close()