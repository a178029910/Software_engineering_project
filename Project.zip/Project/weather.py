import requests
import json
from bs4 import BeautifulSoup


def getcitynumber(city):
    location=r"C:\Users\HASEE\Desktop\aaa\System\page\weather\weathertrue.json"
    with open(location,'r',encoding = 'utf-8') as load_f:
        cities = json.load(load_f)
    for citied in cities:
        if citied['cityName'] == city:
            number = citied['cityCode']
            break
    return number
    return 'flase'

def getinformation(number):
    if number == 'flase':
        return 'flase'
    url = 'http://www.weather.com.cn/weather/'+number+'.shtml'
    headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:62.0) Gecko/20100101 Firefox/62.0',
        }
    html = requests.get(url, headers=headers)
    html.encoding = 'utf-8'
    htmlText = html.text
    soup = BeautifulSoup(htmlText, 'html.parser')
    date = []
    weather = []
    templerature = []
    fengge=[]
    lis = soup.find_all('li', class_='sky')
    for li in lis:
        h1_dates = li.find_all('h1')
        p_weas = li.find_all('p', class_='wea')
        p_tems = li.find_all('p', class_='tem')
        fengs = li.find_all('p', class_='win')
        [date.append(h1_date.text) for h1_date in h1_dates]
        [weather.append(p_wea.text) for p_wea in p_weas]
        [templerature.append(p_tem.text.strip()) for p_tem in p_tems]
        [fengge.append(feng.text.strip()) for feng in fengs]
    print(date)
    print(weather)
    print(fengge)
    templerature[0]=templerature[0]+'/'+templerature[0]
    total=[]
    for t in templerature:
        highandlow=t.split('/')
        hal=[]
        for value in highandlow:
            hal.append(value)
        total.append(hal)
    print(total)
    data={
        "date":date,
        "weather":weather,
        "wind":fengge,
        "temperature":total
    }
    return data

if __name__ == '__main__':
    number = getcitynumber('吴江')
    getinformation(number)
