import os

import pandas as pd

# def file_name(file_dir):
#     for root, dirs, files in os.walk(file_dir):
#         pass
#     f='DataAnalysis/DATA/'+files[0]
#     return f


def createindex(f):
    df = pd.read_excel(f,'Sheet1')
    df.to_csv('data.csv',encoding='utf-8')
    labels = list(df.columns.values) # 获得第一行元素
    return labels


if __name__ == '__main__':
    # f=file_name('areas.xlsx')
    createindex('areas.xlsx')