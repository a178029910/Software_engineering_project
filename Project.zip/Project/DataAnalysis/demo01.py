from matplotlib import pyplot as plt

x = range(2,28,2)

y = [15,13,14,5,17,20,25,26,15,24,22,18,5]

plt.plot(x,y)
plt.show()