import requests,re
from bs4 import BeautifulSoup

def parse_page(url):
    headers = {
        'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'
    }
    response = requests.get(url,headers=headers)
    text =response.content.decode('utf-8')
    soup = BeautifulSoup(text,'lxml')
    Total=[]
    numbers = soup.find_all('div',class_='number-tag')
    for number in numbers:
        Total.append(number.string)
    # USA = soup.find_all('div',class_='prod tags')
    # for us in USA:
    #     infos = list(us.stripped_strings)
    #     Amercian.append(infos)
    China=[]
    CN = soup.find_all('div',class_='prod')
    for cn in CN:
        infos = list(cn.stripped_strings)
        China.append(infos)
    # print(China)
    # print(Amercian)
    # print(Total)
    Amercian = []
    Chinese =[]
    Country = []
    i=0
    j=0
    for china in China:
        if china[0] == '香港':
            break
        Amercian.append(china)
        i=i+1
    for china in China:
        if china[0] == 'US':
            break
        j=j+1
    Chinese.extend(China[i:j])
    Country.extend(China[j:])
    # print(i,j)
    # print('*' * 50)
    # print(Amercian)
    # print('*' * 50)
    # print(Chinese)
    # print('*' * 50)
    # print(Country)
    data={}
    data['Total']=Total
    data['Amercian']=Amercian
    data['Chinese']=Chinese
    data['Country']=Country
    return data


def main():
    url='http://m.sinovision.net/newpneumonia.php'
    data = parse_page(url)
    # print(data)
    return data


if __name__ == '__main__':
    main()