import re  # 正则
import time  # 时间
import pymysql  # Mysql数据库
import requests  # 请求库
from bs4 import BeautifulSoup  # BS4
from hashlib import sha1  # 算法库
import random   # 随机
import font  # 自定义font
from lxml import etree  # 类xml分析

head = """
Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Encoding:gzip, deflate, br
Accept-Language:zh-CN,zh;q=0.9
Cache-Control:max-age=0
Connection:keep-alive
Host:maoyan.com
Upgrade-Insecure-Requests:1
Content-Type:text/html; charset=utf-8
User-Agent:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36
"""  # 全局变量


# def load(name, pwd):
#     db = pymysql.connect(host='localhost', port=3366, user='root', passwd='123', db='maoyan', charset='utf8')
#     # 接收用户输入
#     res = name
#     # 对密码加密
#     # m = sha1()
#     # s = m.update(pwd.encode("utf-8"))
#     # print(s)
#     pwd2 = sha1(pwd.encode('utf-8')).hexdigest()
#     # 根据用户名查询密码
#
#     sql = 'select password from userinfo where name=%s'
#     cursor = db.cursor()
#     cursor.execute(sql, res)
#     psw = cursor.fetchall()
#     db.commit()
#     cursor.close()
#     db.close()
#     if psw == ():
#         return 0
#     elif psw[0][0] == pwd2:
#         return 1
#     else:
#         return 2


def str_to_dict(header):
    """
    构造请求头,可以在不同函数里构造不同的请求头
    """
    header_dict = {}
    header = header.split('\n')
    for h in header:
        h = h.strip()
        if h:
            k, v = h.split(':', 1)
            header_dict[k] = v.strip()
    return header_dict


def get_url():  # 获取电影详情页链接
    for k in range(5):
        for i in range(0, 150, 30):
            time.sleep(2)
            url = 'https://maoyan.com/films?showType=3&sortId=3&yearId=' + str(k + 14) + '&offset=' + str(i)
            host = 'Referer:https://maoyan.com/films?showType=3&sortId=3&yearId=10'
            header = head + host
            headers = str_to_dict(header)   # 构造了头
            try:
                response = requests.get(url=url, headers=headers)  # get请求
            except:
                continue
            html = response.text
            soup = BeautifulSoup(html, 'lxml')
            data_1 = soup.find_all('div', {'class': 'channel-detail movie-item-title'})  # 找数据
            data_2 = soup.find_all('div', {'class': 'channel-detail channel-detail-orange'})
            num = 0
            for item in data_1:
                num += 1
                time.sleep(random.random() * 3)
                url_1 = item.select('a')[0]['href']
                if data_2[num - 1].get_text() != '暂无评分':
                    print('********************', num, 'start********************')
                    url = 'https://maoyan.com' + url_1
                    # print(url)  得到每个url即每个电影的细节
                    for message in get_message(url):  # 这边要理解get_message是一个迭代器，返回一个data即message
                         print(message)
                         # to_mysql(message)
                    print('********************', num, 'end********************\n')
                else:
                    continue


def get_message(url):  # 获取电影详情页里的信息 它是一个迭代器
    """
    获取电影详情页里的信息
    """
    time.sleep(1)
    data = {}
    header = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'Cache-Control': 'max-age=0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
        'Refer': 'https://maoyan.com/films?showType=3&sortId=3&yearId=2019&offset=1',
        'Cookie': '__mta=249977145.1583671185160.1583763144922.1583764039914.20; uuid_n_v=v1; uuid=E28D90A0613911EAB27ABDE6964F79434D1CC627A8C542068B482E27B9DD41F9; _lxsdk_cuid=170ba288a1dc8-09301f2aed33c1-4313f6a-1fa400-170ba288a1e0; mojo-uuid=9e304d4b079c736a09e72e01825d8a3f; mojo-session-id={"id":"1965d6cbe95905a4831014832c6ad168","time":1583760311686}; _csrf=1a8231d68001a5ec67bdd70093d70c189f0e80e98293577f0c3406a03b2b1ca1; Hm_lvt_703e94591e87be68cc8da0da7cbd0be2=1583671184,1583760312,1583760447; _lxsdk=E28D90A0613911EAB27ABDE6964F79434D1CC627A8C542068B482E27B9DD41F9; __mta=249977145.1583671185160.1583760682658.1583761215442.18; Hm_lpvt_703e94591e87be68cc8da0da7cbd0be2=1583764040; mojo-trace-id=61; _lxsdk_s=170bf7885a6-fdc-a22-08%7C%7C103'
    }
    try:
        resp = requests.get(url=url, headers=header)
    except:
        print("这里是每部电影出错的地方")
        return data
    resp = resp.text  # 获得了信息
    # print(resp)
    # 获取编码字典
    font_dict = font.getFont(resp)
    # 替换页面中的编码
    for key in font_dict.keys():
        resp = resp.replace(key, font_dict[key])

    # 获取评分、票房等数据
    body = etree.HTML(resp)
    mark_info = body.xpath('//div[@class="movie-index"]/div')
    mark = mark_info[0].xpath('string(.)').replace(' ', '')
    mark = re.sub(r'\n+', '|', mark)[1:-1].split('|')
    if len(mark) < 2:
        myMark = ''
        myNum = ''
    else:
        myMark = mark[0]
        myNum = mark[1][:-3]
    boxOffice = mark_info[1].xpath('string(.)').replace(' ', '').replace('\n', '')
    print(myMark, myNum, boxOffice)  # 分别为评分 数量 票房
    # 获取电影信息
    soup = BeautifulSoup(resp, "lxml")
    ell = soup.find_all('li', {'class': 'ellipsis'}) # 其他数据
    print(ell)
    name = soup.find_all('h1', {'class': 'name'}) # 电影名字
    people = soup.find_all('a', {'class': 'name'}) # 演员
    # 返回电影信息
    if name:
        data["name"] = name[0].get_text()
    data["time"] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    if ell:
        type = ell[0].get_text().strip().split('\n')
        # print(type)
        if len(type) > 0:
            data["type1"] = type[0]
        if len(type) > 1:
            data["type2"] = type[1]
        if len(type) > 2:
            data["type3"] = type[2]
        if len(type) > 3:
            data["type4"] = type[3]
        if len(type) > 4:
            data["type5"] = type[4]
        if len(ell[1].get_text().split('/')) > 0:
            data["country"] = ell[1].get_text().split('/')[0].replace('\n', '').replace(' ', '')
        if len(ell[1].get_text().split('/')) > 1:
            data["length"] = ell[1].get_text().split('/')[1].replace('\n', '').replace(' ', '')
        try:
            if ell[2].get_text()[:10]:
                string = ell[2].get_text()[:10]
            if string.split('-')[0]:
                data['year'] = int(string.split('-')[0])
            if string.split('-')[0]:
                data['month'] = int(string.split('-')[1])
            if string.split('-')[2]:
                data['day'] = int(string.split('-')[2])
        except:
            pass
    if people:
        data['director'] = people[0].get_text().replace('\n', '').replace(' ', '')
        if len(people) > 2:
            data['actor1'] = people[1].get_text().replace('\n', '').replace(' ', '')
        if len(people) > 3:
            data['actor2'] = people[2].get_text().replace('\n', '').replace(' ', '')
        if len(people) > 4:
            data['actor3'] = people[3].get_text().replace('\n', '').replace(' ', '')
        if len(people) > 5:
            data['actor4'] = people[4].get_text().replace('\n', '').replace(' ', '')
    # 因为会出现没有票房的电影,所以这里需要判断
    data["score"] = myMark
    boxOffice = boxOffice.replace('美元', '')
    if '万' in myNum:
        data["people"] = int(float(myNum.replace('万', '')) * 10000)
    elif len(myNum) == 0:
        data["people"] = 0
    else:
        data["people"] = int(float(myNum))
    if '万' in boxOffice:
        data["box_office"] = int(float(boxOffice.replace('万', '')) * 10000)
    elif '暂无' in boxOffice:
        data["box_office"] = 0
    elif '亿' in boxOffice:
        data["box_office"] = int(float(boxOffice.replace('亿', '')) * 100000000)
    else:
        data["box_office"] = int(float(boxOffice))
    yield data


def to_mysql(data):
    """
    信息写入mysql
    """
    table = 'films2020'
    keys = ', '.join(data.keys())
    values = ', '.join(['%s'] * len(data)) # 占位符%s
    db = pymysql.connect(host='localhost', user='root', password='123', port=3366, db='maoyantest')
    cursor = db.cursor()
    sql = 'INSERT INTO {table}({keys}) VALUES ({values})'.format(table=table, keys=keys, values=values)
    try:
        if cursor.execute(sql, tuple(data.values())): # 这边是需要传入一个元组就可以传入value值
            print("Successful")
            db.commit()
    except:
        print('Failed')
        db.rollback()
    db.close()


def main():
    get_url()


if __name__ == '__main__':
    main()